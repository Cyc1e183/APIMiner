<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "Document name";
 * $l['d{hid}_desc'] = "Document description";
 * $l['d{hid}_document'] = "Document text";
 */
