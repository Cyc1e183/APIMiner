<!-- Output for Theme API test -->
Success: Template overridden.
