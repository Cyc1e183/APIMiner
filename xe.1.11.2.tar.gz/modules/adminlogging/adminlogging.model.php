<?php
/* Copyright (C) NAVER <http://www.navercorp.com> */

/**
 * adminloggingModel class
 * model class of adminlogging module
 *
 * @author NAVER (developers@xpressengine.com)
 * @package /modules/adminlogging
 * @version 0.1
 */
class adminloggingModel extends adminlogging
{
	
}
/* End of file adminlogging.model.php */
/* Location: ./modules/adminlogging/adminlogging.model.php */
