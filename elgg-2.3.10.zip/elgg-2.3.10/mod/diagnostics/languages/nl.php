<?php
return array(
	'admin:administer_utilities:diagnostics' => 'Systeemdiagnose',
	'diagnostics' => 'Systeemdiagnose',
	'diagnostics:report' => 'Diagnostisch rapport',
	'diagnostics:description' => 'Het volgende diagnostische rapport is nuttig voor de diagnose van problemen met Elgg, en moet worden bijgevoegd aan een bugreport die je indient.',
	'diagnostics:header' => '========================================================================
		Elgg diagnostisch rapport
		Gegenereerd %s door %s
========================================================================
',
	'diagnostics:report:basic' => '
Elgg-release %s, versie %s
		
------------------------------------------------------------------------',
	'diagnostics:report:php' => '
PHP-informatie:
%s
------------------------------------------------------------------------',
	'diagnostics:report:plugins' => '
Geïnstalleerde plugins en details:

%s
------------------------------------------------------------------------',
	'diagnostics:report:md5' => '
Geïnstalleerde bestanden en checksums:
			
%s
------------------------------------------------------------------------',
	'diagnostics:report:globals' => '
Algemene variabelen:
			
%s
------------------------------------------------------------------------',
);