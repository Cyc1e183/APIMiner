<?php
/**
 * JSON group profile view
 * 
 * @uses $vars['entity']
 */

echo elgg_view_entity($vars['entity']);
