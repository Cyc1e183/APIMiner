<?php

return [
	'default' => [
		'aalborg_theme/' => __DIR__ . '/graphics',
	],
];
