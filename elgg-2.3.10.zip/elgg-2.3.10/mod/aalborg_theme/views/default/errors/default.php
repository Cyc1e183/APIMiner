<?php
/**
 * General error
 */

$message = elgg_echo('error:default:content');

?>

<div class="elgg-box-error">
	<?php echo $message ?>
</div>