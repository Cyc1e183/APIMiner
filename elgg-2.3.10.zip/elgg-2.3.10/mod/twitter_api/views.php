<?php

return [
	'default' => [
		'twitter_api/' => __DIR__ . '/graphics',
	],
];
