<?php
/**
 * Finnish strings
 */

return array(
	'login_as:login_as' => 'Kirjaudu käyttäjänä',
	'login_as:logged_in_as_user' => 'Olet nyt kirjautuneena käyttäjänä %s.',

	'login_as:return_to_user' => 'Kirjaudu ulos käyttäjän %s tilistä',

	'login_as:unknown_user' => 'Tuntematon käyttäjä. Kirjautuminen epäonnistui.',
	'login_as:could_not_login_as_user' => 'Ei voitu kirjautua käyttäjänä %s',
);
