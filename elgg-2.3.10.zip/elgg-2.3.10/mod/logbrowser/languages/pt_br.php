<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Navegador de registros (logs)',
	'logbrowser' => 'navegador de registros (logs)',
	'logbrowser:browse' => 'navegar nos logs do sistema',
	'logbrowser:search' => 'refinar resultados',
	'logbrowser:user' => 'pesquisar pelo nome de usuário',
	'logbrowser:starttime' => 'Momento de início da busca (por exemplo "último segunda", "1 hora atrás")',
	'logbrowser:endtime' => 'Momento de fim da busca',

	'logbrowser:explore' => 'Explorar log',

	'logbrowser:date' => 'Dia e hora',
	'logbrowser:ip_address' => 'Endereço IP',
	'logbrowser:user:name' => 'Usuário',
	'logbrowser:user:guid' => 'Identificador (GUID) do usuário',
	'logbrowser:object' => 'Tipo de Objeto',
	'logbrowser:object:guid' => 'Identificador (GUID) do objeto',
	'logbrowser:action' => 'Ação',
);