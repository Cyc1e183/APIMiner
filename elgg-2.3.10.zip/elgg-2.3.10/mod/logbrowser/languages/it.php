<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Visualizzatore dei log',
	'logbrowser' => 'Visualizzatore dei log',
	'logbrowser:browse' => 'Visualizza i log di sistema',
	'logbrowser:search' => 'Affina i risultati',
	'logbrowser:user' => 'Nome utente da cercare',
	'logbrowser:starttime' => 'A partire da (per esempio "lunedì scorso", "1 ora fa")',
	'logbrowser:endtime' => 'Fino a',

	'logbrowser:explore' => 'Esplora i log',

	'logbrowser:date' => 'Data e ora',
	'logbrowser:ip_address' => 'Indirizzo IP',
	'logbrowser:user:name' => 'Utente',
	'logbrowser:user:guid' => 'GUID dell\'utente',
	'logbrowser:object' => 'Tipo di oggetto',
	'logbrowser:object:guid' => 'GUID dell\'oggetto',
	'logbrowser:action' => 'Azione',
);