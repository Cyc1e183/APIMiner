<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Log arakatzailea',
	'logbrowser' => 'Log arakatzailea',
	'logbrowser:browse' => 'Log arakatzaile sistema',
	'logbrowser:search' => 'Findu emaitzak',
	'logbrowser:user' => 'Erabiltzaile-izena bilatzeko',
	'logbrowser:starttime' => 'Hasiera data (adibidez, "azken astelehena", "orain dela ordu 1")',
	'logbrowser:endtime' => 'Bukaera data',

	'logbrowser:explore' => 'Loga esploratu',

	'logbrowser:date' => 'Data eta denbora',
	'logbrowser:ip_address' => 'IP helbidea',
	'logbrowser:user:name' => 'Erabiltzailea',
	'logbrowser:user:guid' => 'Erabiltzaile GUID',
	'logbrowser:object' => 'Objektu mota',
	'logbrowser:object:guid' => 'Objektu GUID',
	'logbrowser:action' => 'Akzioa',
);