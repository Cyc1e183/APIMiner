<?php
return array(
	'admin:administer_utilities:logbrowser' => '로그 표시기',
	'logbrowser' => '로그 표시기',
	'logbrowser:browse' => '시스템로그 표시',
	'logbrowser:search' => '결과 미세조절',
	'logbrowser:user' => '검색할 사용자 이름',
	'logbrowser:starttime' => '시작시간(예: 지난 월요일, 한시간전 등)',
	'logbrowser:endtime' => '끝시간',

	'logbrowser:explore' => '로그 검색',

	'logbrowser:date' => '날짜와 시간',
	'logbrowser:ip_address' => 'IP 주소',
	'logbrowser:user:name' => '사용자',
	'logbrowser:user:guid' => '사용자 GUID',
	'logbrowser:object' => '객체 종류',
	'logbrowser:object:guid' => '객체 GUID',
	'logbrowser:action' => '행동',
);