<?php
return array(
	'admin:administer_utilities:logbrowser' => 'ログブラウザ',
	'logbrowser' => 'ログブラウザ',
	'logbrowser:browse' => 'システムログの閲覧',
	'logbrowser:search' => '結果を絞り込む',
	'logbrowser:user' => 'ログイン名での検索',
	'logbrowser:starttime' => '開始時間(例: "last monday", "1 hour ago")',
	'logbrowser:endtime' => '終了時間',

	'logbrowser:explore' => 'ログの探索',

	'logbrowser:date' => '日付と時間',
	'logbrowser:ip_address' => 'IP address',
	'logbrowser:user:name' => 'User',
	'logbrowser:user:guid' => 'User GUID',
	'logbrowser:object' => 'Object type',
	'logbrowser:object:guid' => 'Object GUID',
	'logbrowser:action' => 'Action',
);