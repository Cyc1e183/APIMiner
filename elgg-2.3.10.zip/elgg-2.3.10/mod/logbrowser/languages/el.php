<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Αρχεία καταγραφής',
	'logbrowser' => 'Αρχεία καταγραφής',
	'logbrowser:browse' => 'Αρχεία καταγραφής συστήματος',
	'logbrowser:search' => 'Βελτίωση αποτελεσμάτων',
	'logbrowser:user' => 'Όνομα χρήστη για αναζήτηση',
	'logbrowser:starttime' => 'Ώρα έναρξης (για παράδειγμα "last monday", "1 hour ago")',
	'logbrowser:endtime' => 'Ώρα λήξης',

	'logbrowser:explore' => 'Εξερεύνηση αρχείου καταγραφής',

	'logbrowser:date' => 'Ημερομηνία και ώρα',
	'logbrowser:ip_address' => 'Διεύθυνση IP',
	'logbrowser:user:name' => 'Χρήστης',
	'logbrowser:user:guid' => 'Κωδικός χρήστη (GUID)',
	'logbrowser:object' => 'Τύπος αντικειμένου',
	'logbrowser:object:guid' => 'Κωδικός αντικειμένου (GUID)',
	'logbrowser:action' => 'Ενέργεια',
);