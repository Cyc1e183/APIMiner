<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Przeglądarka plików rejestrowych',
	'logbrowser' => 'Przeglądarka plików rejestrowych',
	'logbrowser:browse' => 'Przeglądaj systemowe pliki rejestrowe',
	'logbrowser:search' => 'Zawęź wyniki',
	'logbrowser:user' => 'Użytkownik szuka ',
	'logbrowser:starttime' => 'Początkowy czas',
	'logbrowser:endtime' => 'Końcowy czas',

	'logbrowser:explore' => 'Przeglądaj pliki rejestrowe',

	'logbrowser:date' => 'Data i czas',
	'logbrowser:ip_address' => 'Adres IP',
	'logbrowser:user:name' => 'Użytkownik',
	'logbrowser:user:guid' => 'GUID użytkownika',
	'logbrowser:object' => 'Rodzaj obiektu',
	'logbrowser:object:guid' => 'GUID obiektu',
	'logbrowser:action' => 'Działanie',
);