<?php
return array(
	'admin:administer_utilities:logbrowser' => '記錄檔瀏覽器',
	'logbrowser' => '記錄檔瀏覽器',
	'logbrowser:browse' => '瀏覽系統日誌',
	'logbrowser:search' => '重整結果',
	'logbrowser:user' => '搜尋使用者名稱依據',
	'logbrowser:starttime' => '開始時間 (舉例來說：上星期一", "一小時之前")',
	'logbrowser:endtime' => '結束時間',

	'logbrowser:explore' => '探查記錄檔',

	'logbrowser:date' => '日期與時間',
	'logbrowser:ip_address' => 'IP 位址',
	'logbrowser:user:name' => '使用者',
	'logbrowser:user:guid' => '使用者 GUID',
	'logbrowser:object' => '物件類型',
	'logbrowser:object:guid' => '物件 GUID',
	'logbrowser:action' => '動作',
);