<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Logbrowser',
	'logbrowser' => 'Logbrowser',
	'logbrowser:browse' => 'Bekijk systeem-logboek',
	'logbrowser:search' => 'Verfijn resultaten',
	'logbrowser:user' => 'Gebruikersnaam om op te zoeken',
	'logbrowser:starttime' => 'Begintijd (bijvoorbeeld "afgelopen maandag", "1 uur geleden")',
	'logbrowser:endtime' => 'Eindtijd',

	'logbrowser:explore' => 'Verken logboek',

	'logbrowser:date' => 'Datum en tijd',
	'logbrowser:ip_address' => 'IP-adres',
	'logbrowser:user:name' => 'Gebruiker',
	'logbrowser:user:guid' => 'Gebruiker GUID',
	'logbrowser:object' => 'Objecttype',
	'logbrowser:object:guid' => 'Object GUID',
	'logbrowser:action' => 'Actie',
);