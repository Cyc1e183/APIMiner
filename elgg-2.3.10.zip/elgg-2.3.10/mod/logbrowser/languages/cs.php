<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Procházet logy',
	'logbrowser' => 'Procházet logy',
	'logbrowser:browse' => 'Procházet systémový log',
	'logbrowser:search' => 'Zpřesnit výsledky',
	'logbrowser:user' => 'Filtrovat podle uživatele',
	'logbrowser:starttime' => 'Čas počátku (anglicky, např. "last monday", "1 hour ago")',
	'logbrowser:endtime' => 'Čas konce',

	'logbrowser:explore' => 'Prozkoumat log',

	'logbrowser:date' => 'Datum a čas',
	'logbrowser:ip_address' => 'IP adresa',
	'logbrowser:user:name' => 'Uživatel',
	'logbrowser:user:guid' => 'ID uživatele',
	'logbrowser:object' => 'Typ položky',
	'logbrowser:object:guid' => 'ID položky',
	'logbrowser:action' => 'Akce',
);