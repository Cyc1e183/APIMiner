<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Lokiselain',
	'logbrowser' => 'Lokiselain',
	'logbrowser:browse' => 'Selaa järjestelmän lokia',
	'logbrowser:search' => 'Suodata tuloksia',
	'logbrowser:user' => 'Käyttäjätunnus, jonka lokimerkintöjä haluat selata',
	'logbrowser:starttime' => 'Alkamisaika (muodossa 2012-08-27 18:11:31)',
	'logbrowser:endtime' => 'Päättymisaika',

	'logbrowser:explore' => 'Selaa lokia',

	'logbrowser:date' => 'Päivämäärä ja aika',
	'logbrowser:ip_address' => 'IP-osoite',
	'logbrowser:user:name' => 'Käyttäjä',
	'logbrowser:user:guid' => 'Käyttäjän GUID',
	'logbrowser:object' => 'Kohteen tyyppi',
	'logbrowser:object:guid' => 'Kohteen GUID',
	'logbrowser:action' => 'Toiminto',
);