<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Журнал логов',
	'logbrowser' => 'Журнал логов',
	'logbrowser:browse' => 'Смотреть системные логи',
	'logbrowser:search' => 'Обновить',
	'logbrowser:user' => 'Пользователь',
	'logbrowser:starttime' => 'Начало периода (например, "прошлый понедельник", "1 час назад")',
	'logbrowser:endtime' => 'Конец периода',

	'logbrowser:explore' => 'Просмотреть лог',

	'logbrowser:date' => 'Дата и время',
	'logbrowser:ip_address' => 'IP адрес',
	'logbrowser:user:name' => 'Пользователь',
	'logbrowser:user:guid' => 'GUID пользователя',
	'logbrowser:object' => 'Типо объекта',
	'logbrowser:object:guid' => 'GUID объекта',
	'logbrowser:action' => 'Действие',
);