<?php
return array(
	'admin:administer_utilities:logbrowser' => 'Navegador do rexistro',
	'logbrowser' => 'Navegador do rexistr',
	'logbrowser:browse' => 'Navegar polo rexistro do sistema',
	'logbrowser:search' => 'Afinar os resultados',
	'logbrowser:user' => 'Nome de usuario para buscar',
	'logbrowser:starttime' => 'Tempo de comezo (por exemplo, «last monday» [último luns] ou «1 hour ago» [hai 1 hora])',
	'logbrowser:endtime' => 'Tempo de remate',

	'logbrowser:explore' => 'Explorar o rexistr',

	'logbrowser:date' => 'Data e hora',
	'logbrowser:ip_address' => 'Enderezo IP',
	'logbrowser:user:name' => 'Usuari',
	'logbrowser:user:guid' => 'GUID do usuario',
	'logbrowser:object' => 'Tipo de obxecto',
	'logbrowser:object:guid' => 'GUID do obxecto',
	'logbrowser:action' => 'Acción',
);