<?php

return [
	'default' => [
		'file/icons/' => __DIR__ . '/graphics/icons',
	],
];
