<?php
return array(

	'friends:invite' => '邀请朋友',
	
	'invitefriends:registration_disabled' => '本站的新用户注册功能暂时关闭；已无法邀请新用户注册。',
	
	'invitefriends:introduction' => '邀请朋友加入，请输入他们的email地址， 他们将收到您的邀请邮件。',
	'invitefriends:emails' => 'Email 地址 (每行一条)',
	'invitefriends:message' => '消息',
	'invitefriends:subject' => '加入 %s 的邀请',

	'invitefriends:success' => '已邀请您的朋友。',
	'invitefriends:invitations_sent' => '邀请发送： %s 。 问题是：',
	'invitefriends:email_error' => '下面的地址无效： %s',
	'invitefriends:already_members' => '下面的地址已加入本站： %s',
	'invitefriends:noemails' => '未输入任何有效的email。',
	
	'invitefriends:message:default' => '您好, 

我邀请你加入这个网站，地址为 %s.',

	'invitefriends:email' => '欢迎加入 %s ，您的朋友 %s 给您发了邀请函：

%s

点击下面的链接，进行注册：

%s

您注册成功后将自动与他（她）成为好友。',
	
);
