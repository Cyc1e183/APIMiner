<?php
return array(

	'friends:invite' => 'Lagunak gonbidatu',
	
	'invitefriends:registration_disabled' => 'Erabiltzaile berrien erregistroa desgaitu da gune honetan; ezin duzu erabiltzaile berriak gonbidatu.',
	
	'invitefriends:introduction' => 'Lagunak sare honetara batzea gonbidatzeko, sartu haien email helbideak eta mezu bat zure gonbidapenarekin jaso dezaten.',
	'invitefriends:emails' => 'Email helbideak (bat lerro bakoitzeko)',
	'invitefriends:message' => 'Mezua',
	'invitefriends:subject' => '%s batzera gonbidatu',

	'invitefriends:success' => 'Zure lagunak gonbidatuak izan dira.',
	'invitefriends:invitations_sent' => 'Gonbidapenak bidalita: %s. Hurrengo arazo hauek egon dira:',
	'invitefriends:email_error' => 'Hurrengo email helbideak ez dira zuzenak: %s',
	'invitefriends:already_members' => 'Hurrengoak jada kide dira: %s',
	'invitefriends:noemails' => 'Ez da email helbiderik sartu.',
	
	'invitefriends:message:default' => 'Kaixo,

Nire sarera gonbidatu nahi zaitut hemen %s.',

	'invitefriends:email' => '%s batzeko gonbidapena jaso duzu %s-ek bidalita. Hurrengo mezua dakar:

%s

Batzeko, klikatu hurrengo estekan:

%s

Automatikoki gehituko zara bertara lagun bezala zure kontua sortzen duzunean.',
	
);
